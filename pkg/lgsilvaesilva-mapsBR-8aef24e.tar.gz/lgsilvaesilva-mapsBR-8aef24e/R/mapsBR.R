# regMun    <- shape.file.mun
# regMicro  <- shape.file.micro
# regMeso   <- shape.file.meso
# regUF     <- shape.file.uf
# regRegiao <- shape.file.regiao
# regSaude  <- shape.file.regioes.saude
# 
# save(regMun, file = 'data/regMun.RData')
# save(regMicro, file = 'data/regMicro.RData')
# save(regMeso, file = 'data/regMeso.RData')
# save(regUF, file = 'data/regUF.RData')
# save(regRegiao, file = 'data/regRegiao.RData')
# save(regSaude, file = 'data/regSaude.RData')

# sapply(file.path('data', list.files('data')), FUN = load, .GlobalEnv)
 